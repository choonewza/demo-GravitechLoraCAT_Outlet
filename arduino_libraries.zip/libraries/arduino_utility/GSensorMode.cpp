#include "GSensorMode.h"

GSensorMode::~GSensorMode(){
//	Serial.println(F("Debug: GSensorMode is destroyed."));
}

GSensorMode::GSensorMode(){
	
}

void GSensorMode::setName(const char* name){
	this->name = String(name);
}
String GSensorMode::getName(){
	return this->name;
}

bool GSensorMode::isActive(uint16_t sensorValue){
	Serial.println("isActive is NOT IMPLEMENTATION.");
	return false;
}

void GSensorMode::enableMoreThenMode(uint16_t activeSensorValue){
	Serial.println("enableMoreThenMode is NOT IMPLEMENTATION.");
}

void GSensorMode::enableLessThenMode(uint16_t activeSensorValue){
	Serial.println("enableLessThenMode is NOT IMPLEMENTATION.");
}

void GSensorMode::enableBetweenMode(uint16_t maxActiveSensorValue, uint16_t minActiveSensorValue){
	Serial.println("enableBetweenMode is NOT IMPLEMENTATION.");
}

void GSensorMode::enableNotBetweenMode(uint16_t maxActiveSensorValue, uint16_t minActiveSensorValue){
	Serial.println("enableNotBetweenMode is NOT IMPLEMENTATION.");
}


bool GSensorMode::isActive(float sensorValue){
	Serial.println("isActive is NOT IMPLEMENTATION.");
	return false;
}

void GSensorMode::enableMoreThenMode(float activeSensorValue){
	Serial.println("enableMoreThenMode is NOT IMPLEMENTATION.");
}

void GSensorMode::enableLessThenMode(float activeSensorValue){
	Serial.println("enableLessThenMode is NOT IMPLEMENTATION.");
}

void GSensorMode::enableBetweenMode(float maxActiveSensorValue, float minActiveSensorValue){
	Serial.println("enableBetweenMode is NOT IMPLEMENTATION.");
}

void GSensorMode::enableNotBetweenMode(float maxActiveSensorValue, float minActiveSensorValue){
	Serial.println("enableNotBetweenMode is NOT IMPLEMENTATION.");
}

