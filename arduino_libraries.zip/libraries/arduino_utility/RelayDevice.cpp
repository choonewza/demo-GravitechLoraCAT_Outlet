#include "RelayDevice.h"

RelayDevice::~RelayDevice(){
//	Serial.println(F("Debug: RelayDevice is destroyed."));
}

RelayDevice::RelayDevice(const char* name): GDevice(name) {

}

RelayDevice::RelayDevice(const char* name, uint8_t pin): GDevice(name, pin) {

}

RelayDevice::RelayDevice(const char* name, uint8_t pin, uint8_t mode): GDevice(name, pin, mode) {

};





